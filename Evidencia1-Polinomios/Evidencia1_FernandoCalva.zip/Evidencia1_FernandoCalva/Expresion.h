struct Box;
struct Rac;

struct Expresion{
	Box *BoxOp1,*BoxOp2,*BoxResult;
	Box *BoxOperador;
	static Box *BoxIgual;
	long longMaxAlturaDBox;
	static COORD COORD_C;
	Expresion(Box *Op1,Box *Operador,Box *Op2,Box *Result);
	Expresion();
	virtual void print();
};
struct Box{
	int intLongDBase;
	int intLongDAltura;
	virtual void set_coord(COORD c)=0;
	virtual Rac *get_Rac()=0;
	virtual int get_intLongDBase()=0;
	virtual char get_op()=0;
	virtual void print(COORD)=0;
};
struct BoxStringEqual : public Box{
	static std::string equal;
	COORD coord;
	BoxStringEqual();
	void set_coord(COORD c);
	Rac *get_Rac();
	int get_intLongDBase();
	char get_op();
	void print(COORD);
};
struct BoxRac : public Box{
	Rac *R;
	COORD coord;
	BoxRac(Rac *r);
	void set_coord(COORD c);
	Rac *get_Rac();
	int get_intLongDBase();
	char get_op();
	void print(COORD);
};
struct BoxStringOperator : public Box{
	char op;
	COORD coord;
	BoxStringOperator(char);
	void set_coord(COORD c);
	Rac *get_Rac();
	int get_intLongDBase();
	char get_op();
	void print(COORD);
};
struct ExpresionASimplificar : public Expresion{
	Rac *RacOrig;
	Rac *RacSimpl;
	//ExpresionASimplificar(Rac *RacObj);
	ExpresionASimplificar(Box *Op1,Box *Op2);
	ExpresionASimplificar(Box *Op1);
	void print();
};