Evidencia N�mero 1 para la materia de Programaci�n Avanzada
Alumno: Fernando Alonso Calva S�nchez

Descripci�n: El programa realiza a trav�s de terminal diversas operaciones con polinomios, para lo cual se cuenta con los siguientes comandos:

� p1=[coef1,coef2,coef3,coef4,coef5,...,coefn]
    //Donde p1 puede ser cualquier nombre de variable sin espacios y
    //coef1... coefn son n�meros enteros

� p1#p2
    //Suma de polinomios, con p1 y p2 de cualquier grado

� p1~p2
    //Resta de polinomios, con p1 y p2 de cualquier grado

� p1xp2
    //Multiplicaci�n de polinomios, con p1 y p2 de cualquier grado

� showp
    //Muestra los polinomios almacenados

� clearp
    //Borra los polinomios almacenados

� clc
    //Borra lo que se encuentra en pantalla