/*
 * Programación Avanzada - Evidencia 3
 * GUI con Comunicación Serial
 * Fernando Alonso Calva Sánchez
 */
package serialgui;

import jssc.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

public class SerialGUI implements ActionListener{ // 2/5
    //Comenzando comunicación Serial
    static SerialPort puerto;
    static int mascara;
    
    //Gnerando Interfaz Gráfica
    Frame F;
    Panel P;
    TextField TF1;
    Button BotonEnviar;
    TextArea TA;
    public SerialGUI(){
        F=new Frame("Transmisor de información");
        F.setLayout(new BorderLayout());
        P=_llenar_Panel();
        F.add(P, BorderLayout.NORTH);
        TA=new TextArea();
        F.add(TA, BorderLayout.CENTER);
        F.addWindowListener(new WindowAdapter(){// 3/5 del Frame F
           public void windowClosing(WindoEvent we) {
               F.dispose();
               System.exit(0);
           }
        });
        BotonEnviar.addActionListener(this);// 3/5 Button BotonAgregarEvid
        
        F.setLocationRelativeTo(null);
        F.setSize(600,450);
        F.setResizable(false);
        F.setVisible(true);
    }//end EvidsChecking();
    private Panel _llenar_Panel(){
        Panel p=new Panel();
        p.setLayout(new FlowLayout());
        TF1=new TextField(50);
        TF1.setText("Ingrese aquí el número a enviar");
        BotonEnviar=new Button("Enviar dato");
        p.add(TF1);
        p.add(BotonEnviar);
        return p;
    }
    public static void main(String[] args) throws SerialPortException{
        new SerialGUI();

        puerto = new SerialPort("/dev/ttyUSB0"); // Inicializamos el puerto
        puerto.openPort(); // Abriendo puerto
        puerto.setParams(9600, 8, 1, 0); // Parametros de comunicación
        mascara = SerialPort.MASK_RXCHAR; // Seleccionamo el tipo de máscara
        puerto.setEventsMask(mascara);	// Aplica la máscara a nuestro stream
    }
   
    @Override
    public void actionPerformed(ActionEvent ae) {// 4/5
        if(ae.getSource().equals(BotonEnviar)){// 5/5
            String str=TF1.getText();
            TF1.setText("");
            String str2=TA.getText();
            if(str2.equals("")==false){
                str2=str2+"\n";
            }
            try {
                puerto.writeString(str); // LO que escribió lo mandamos al puerto serie            
            } catch (SerialPortException ex) {
                Logger.getLogger(SerialGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            str2=str2+"\nSe envió el número: "+str;
            TA.setText(str2);
        }
    }
}//end class EvidsChecking